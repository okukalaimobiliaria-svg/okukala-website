import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Sobre a OKUKALA - Imobiliária Premium em Angola',
  description: 'Conheça a OKUKALA, a imobiliária premium de Angola dedicada a oferecer imóveis de qualidade com atendimento excepcional.',
}

export default function SobrePage() {
  return (
    <main className="w-full">
      {/* Header */}
      <section className="section-bg-blue py-16 md:py-24">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-gray-900">Sobre a OKUKALA</h1>
          <p className="mt-4 text-xl text-gray-600">Sua parceira imobiliária premium em Angola</p>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 md:grid-cols-3">
            {/* Missão */}
            <div className="rounded-lg border border-gray-200 p-8">
              <h3 className="mb-4 text-2xl font-bold text-okukala-blue">Missão</h3>
              <p className="text-gray-600">
                Conectar pessoas aos imóveis dos seus sonhos através de um serviço confiável, transparente e de excelência em toda Angola.
              </p>
            </div>

            {/* Visão */}
            <div className="rounded-lg border border-gray-200 p-8">
              <h3 className="mb-4 text-2xl font-bold text-okukala-blue">Visão</h3>
              <p className="text-gray-600">
                Ser a imobiliária mais confiável e inovadora em Angola, referência na qualidade de imóveis e atendimento ao cliente.
              </p>
            </div>

            {/* Valores */}
            <div className="rounded-lg border border-gray-200 p-8">
              <h3 className="mb-4 text-2xl font-bold text-okukala-blue">Valores</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Transparência</li>
                <li>• Confiança</li>
                <li>• Qualidade</li>
                <li>• Excelência</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* About Content */}
      <section className="border-t border-gray-200 py-16 md:py-24">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 space-y-8">
          <div>
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Nossa História</h2>
            <p className="text-gray-600">
              A OKUKALA nasceu da paixão em conectar pessoas aos seus imóveis ideais. Com anos de experiência no mercado imobiliário angolano,
              nossa equipe dedica-se a oferecer propriedades de qualidade com um atendimento excepcional.
            </p>
          </div>

          <div>
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Por Que Nos Escolher</h2>
            <ul className="space-y-4 text-gray-600">
              <li className="flex gap-3">
                <span className="text-okukala-blue font-bold">•</span>
                <span>Portfólio curado com as melhores propriedades em Angola</span>
              </li>
              <li className="flex gap-3">
                <span className="text-okukala-blue font-bold">•</span>
                <span>Equipe profissional e dedicada ao seu sucesso</span>
              </li>
              <li className="flex gap-3">
                <span className="text-okukala-blue font-bold">•</span>
                <span>Transparência total em todas as transações</span>
              </li>
              <li className="flex gap-3">
                <span className="text-okukala-blue font-bold">•</span>
                <span>Atendimento personalizado e consultivo</span>
              </li>
              <li className="flex gap-3">
                <span className="text-okukala-blue font-bold">•</span>
                <span>Conhecimento profundo do mercado local</span>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="mb-4 text-2xl font-bold text-gray-900">Nossa Equipe</h2>
            <p className="text-gray-600">
              Somos profissionais experientes dedicados a oferecer a melhor experiência imobiliária. Cada membro da equipe OKUKALA é treinado
              para garantir que você receba suporte excepcional em cada etapa da sua jornada.
            </p>
          </div>
        </div>
      </section>

      {/* Team Members Section */}
      <section className="bg-gray-50 py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-900">Conheça Nossa Equipe</h2>
          
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                nome: 'João Silva',
                cargo: 'Director Executivo',
                descricao: 'Com 15 anos de experiência no mercado imobiliário',
              },
              {
                nome: 'Maria Santos',
                cargo: 'Directora de Vendas',
                descricao: 'Especialista em consultoria imobiliária premium',
              },
              {
                nome: 'Pedro Oliveira',
                cargo: 'Director Operacional',
                descricao: 'Gestor de propriedades e portfólio',
              },
              {
                nome: 'Ana Costa',
                cargo: 'Consultora Senior',
                descricao: 'Especialista em investimentos imobiliários',
              },
              {
                nome: 'Carlos Mendes',
                cargo: 'Consultor Imobiliário',
                descricao: 'Atendimento e consultoria a clientes',
              },
              {
                nome: 'Sofia Dias',
                cargo: 'Especialista em Marketing',
                descricao: 'Responsável por comunicação e marketing digital',
              },
            ].map((membro, idx) => (
              <div key={idx} className="rounded-lg bg-white p-6 text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="mb-4 h-24 w-24 mx-auto rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                  <span className="text-3xl font-bold text-okukala-blue">{membro.nome.charAt(0)}</span>
                </div>
                <h3 className="font-bold text-gray-900">{membro.nome}</h3>
                <p className="text-sm font-semibold text-okukala-blue mt-1">{membro.cargo}</p>
                <p className="text-sm text-gray-600 mt-2">{membro.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Strategic Partners Section */}
      <section className="py-16 md:py-24 border-t border-gray-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-900">Nossos Parceiros Estratégicos</h2>
          
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {[
              {
                nome: 'Banco de Investimento',
                tipo: 'Financiamento',
                descricao: 'Soluções de crédito para imóveis',
              },
              {
                nome: 'Consultoria Legal',
                tipo: 'Jurídico',
                descricao: 'Assessoria legal em transações',
              },
              {
                nome: 'Avaliação Profissional',
                tipo: 'Avaliação',
                descricao: 'Avaliação técnica de propriedades',
              },
              {
                nome: 'Seguros Premium',
                tipo: 'Seguros',
                descricao: 'Coberturas para imóveis e clientes',
              },
              {
                nome: 'Construtora Líder',
                tipo: 'Construção',
                descricao: 'Projetos de desenvolvimento imobiliário',
              },
              {
                nome: 'Gestor Patrimonial',
                tipo: 'Gestão',
                descricao: 'Gestão profissional de propriedades',
              },
              {
                nome: 'Plataforma Digital',
                tipo: 'Tecnologia',
                descricao: 'Ferramentas de marketing digital',
              },
              {
                nome: 'Rede Internacional',
                tipo: 'Networking',
                descricao: 'Conexões com imobiliárias internacionais',
              },
            ].map((parceiro, idx) => (
              <div key={idx} className="rounded-lg border border-gray-200 p-6 hover:border-blue-300 transition-colors">
                <div className="mb-3 h-12 w-12 rounded-lg section-bg-blue flex items-center justify-center">
                  <span className="text-lg font-bold text-okukala-blue">✓</span>
                </div>
                <h3 className="font-bold text-gray-900">{parceiro.nome}</h3>
                <p className="text-xs font-semibold text-okukala-blue mt-1">{parceiro.tipo}</p>
                <p className="text-sm text-gray-600 mt-2">{parceiro.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
