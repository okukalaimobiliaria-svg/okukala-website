import { Metadata } from 'next'
import Link from 'next/link'
import { Bed, Bath, Maximize2, MapPin } from 'lucide-react'
import { ImageGallery } from '@/components/ImageGallery'
import { PropertyDetailClient } from '@/components/PropertyDetailClient'
import { formatPrice } from '@/lib/formatting'

interface PropertyPageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: PropertyPageProps): Promise<Metadata> {
  const { slug } = await params
  return {
    title: `Imóvel - ${slug} - OKUKALA`,
    description: 'Detalhes completos do imóvel. Visite para mais informações.',
  }
}

export default function PropertyPage() {
  // Mock property - Replace with Hygraph query
  const property = {
    slug: 'apartamento-t4-luanda',
    titulo: 'Apartamento T4 Premium em Luanda',
    descricao: 'Apartamento moderno e espaçoso no coração de Luanda, com acabamento de primeira qualidade e localização privilegiada.',
    preco: 85000000,
    cidade: 'Luanda',
    bairro: 'Miramar',
    quartos: 4,
    vagas: 2,
    area: 280,
    imagens: [
      { url: 'https://via.placeholder.com/800x600?text=Apartamento+Principal' },
      { url: 'https://via.placeholder.com/800x600?text=Sala+de+Estar' },
      { url: 'https://via.placeholder.com/800x600?text=Cozinha' },
      { url: 'https://via.placeholder.com/800x600?text=Quarto' },
    ],
  }

  return (
    <main className="w-full">
      {/* Back Link */}
      <section className="border-b border-gray-200 bg-gray-50 py-4">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Link href="/imoveis" className="text-okukala-blue hover:text-okukala-dark font-semibold text-sm">
            ← Voltar para Imóveis
          </Link>
        </div>
      </section>

      {/* Gallery & Details */}
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 md:grid-cols-3">
            {/* Gallery */}
            <div className="md:col-span-2">
              <ImageGallery imagens={property.imagens} titulo={property.titulo} />
            </div>

            {/* Info Card */}
            <div className="rounded-lg border border-gray-200 p-6 h-fit sticky top-20">
              {/* Price */}
              <div className="mb-6 border-b border-gray-200 pb-6">
                <p className="text-sm text-gray-600">Preço</p>
                <p className="text-3xl font-bold text-okukala-blue">{formatPrice(property.preco)}</p>
              </div>

              {/* Features */}
              <div className="mb-6 space-y-3">
                <div className="flex items-center gap-3">
                  <MapPin size={20} className="text-okukala-blue" />
                  <div>
                    <p className="text-sm text-gray-600">Localização</p>
                    <p className="font-semibold text-gray-900">{property.bairro}, {property.cidade}</p>
                  </div>
                </div>
                {property.quartos && (
                  <div className="flex items-center gap-3">
                    <Bed size={20} className="text-okukala-blue" />
                    <div>
                      <p className="text-sm text-gray-600">Quartos</p>
                      <p className="font-semibold text-gray-900">{property.quartos}</p>
                    </div>
                  </div>
                )}
                {property.vagas && (
                  <div className="flex items-center gap-3">
                    <Bath size={20} className="text-okukala-blue" />
                    <div>
                      <p className="text-sm text-gray-600">Vagas</p>
                      <p className="font-semibold text-gray-900">{property.vagas}</p>
                    </div>
                  </div>
                )}
                {property.area && (
                  <div className="flex items-center gap-3">
                    <Maximize2 size={20} className="text-okukala-blue" />
                    <div>
                      <p className="text-sm text-gray-600">Área</p>
                      <p className="font-semibold text-gray-900">{property.area} m²</p>
                    </div>
                  </div>
                )}
              </div>

              {/* CTA Buttons */}
              <PropertyDetailClient slug={property.slug} titulo={property.titulo} />

              {/* Contact Info */}
              <div className="mt-6 rounded-lg section-bg-blue p-4 border border-gray-200">
                <p className="text-sm font-semibold text-gray-900">Dúvidas?</p>
                <p className="mt-2 text-sm text-gray-600">
                  Entre em contato conosco para mais informações sobre este imóvel.
                </p>
                <a href="tel:+244912345678" className="mt-3 inline-block text-sm font-semibold text-okukala-blue hover:text-okukala-dark">
                  +244 912 345 678
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Description */}
      <section className="border-t border-gray-200 py-12 md:py-16">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-4 text-2xl font-bold text-gray-900">Sobre este Imóvel</h2>
          <p className="text-gray-600">{property.descricao}</p>

          <div className="mt-8 rounded-lg bg-gray-50 p-6 border border-gray-200">
            <h3 className="mb-4 font-semibold text-gray-900">Características Principais</h3>
            <ul className="space-y-2 text-gray-600">
              <li>• Acabamento de primeira qualidade</li>
              <li>• Localização privilegiada</li>
              <li>• Áreas comuns seguras e equipadas</li>
              <li>• Proximidade a comércios e serviços</li>
              <li>• Ótima valorização do imóvel</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Location Map */}
      <section className="border-t border-gray-200 py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-8 text-2xl font-bold text-gray-900">Localização</h2>
          
          <div className="grid gap-8 md:grid-cols-2">
            {/* Map */}
            <div className="rounded-lg overflow-hidden border border-gray-200 h-96">
              <iframe
                width="100%"
                height="100%"
                frameBorder="0"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3945.8914345298306!2d13.2344!3d-8.8383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1a51f77d6f6f6f6f%3A0x1a51f77d6f6f6f6f!2sLuanda!5e0!3m2!1spt!2sao!4v1234567890"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>

            {/* Info */}
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Endereço Completo</h3>
                <p className="text-gray-600">{property.bairro}, {property.cidade}, Angola</p>
              </div>

              <div className="rounded-lg section-bg-blue p-6 border border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4">O que há próximo?</h3>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Comércios e shoppings a 500m</li>
                  <li>• Hospitais e clínicas a 1km</li>
                  <li>• Escolas de qualidade a 2km</li>
                  <li>• Parques e áreas verdes a 1km</li>
                  <li>• Restaurantes e bares a 300m</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Properties */}
      <section className="border-t border-gray-200 bg-gray-50 py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-8 text-2xl font-bold text-gray-900">Imóveis Relacionados</h2>
          
          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                titulo: 'Apartamento T3 em Luanda',
                preco: 75000000,
                slug: 'apartamento-t3-luanda',
                imagem: 'https://via.placeholder.com/400x300?text=Relacionado+1',
                tipo: 'Apartamento',
                cidade: 'Luanda',
              },
              {
                titulo: 'Apartamento T5 Miramar',
                preco: 95000000,
                slug: 'apartamento-t5-miramar',
                imagem: 'https://via.placeholder.com/400x300?text=Relacionado+2',
                tipo: 'Apartamento',
                cidade: 'Luanda',
              },
              {
                titulo: 'Lote Residencial em Bengo',
                preco: 50000000,
                slug: 'lote-residencial-bengo',
                imagem: 'https://via.placeholder.com/400x300?text=Relacionado+3',
                tipo: 'Terreno',
                cidade: 'Bengo',
              },
            ].map((related) => (
              <Link
                key={related.slug}
                href={`/imoveis/${related.slug}`}
                className="group rounded-lg border border-gray-200 overflow-hidden bg-white transition-all hover:shadow-lg"
              >
                <div className="relative h-40 overflow-hidden bg-gray-200">
                  <img
                    src={related.imagem}
                    alt={related.titulo}
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <div className="p-4">
                  <p className="text-xs font-semibold text-okukala-blue">{related.tipo}</p>
                  <h3 className="mt-2 font-semibold text-gray-900 line-clamp-2 group-hover:text-okukala-blue">{related.titulo}</h3>
                  <div className="mt-3 flex items-center justify-between">
                    <p className="font-bold text-okukala-blue">{formatPrice(related.preco)}</p>
                    <p className="text-xs text-gray-600">{related.cidade}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

    </main>
  )
}
