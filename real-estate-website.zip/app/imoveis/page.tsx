import { Metadata } from 'next'
import { PropertyFilters } from '@/components/PropertyFilters'
import { PropertyCard } from '@/components/PropertyCard'
import { Pagination } from '@/components/Pagination'

export const metadata: Metadata = {
  title: 'Imóveis à Venda e Aluguel - OKUKALA',
  description: 'Explore nosso catálogo completo de imóveis em Angola. Apartamentos, casas, terrenos e imóveis comerciais.',
}

interface ImoveisPageProps {
  searchParams: Promise<{
    page?: string
    cidade?: string
    precoMin?: string
    precoMax?: string
  }>
}

export default async function ImoveisPage({ searchParams }: ImoveisPageProps) {
  const params = await searchParams
  const page = parseInt(params.page || '1', 10)
  const cidade = params.cidade || ''
  const precoMin = params.precoMin ? parseFloat(params.precoMin) : undefined
  const precoMax = params.precoMax ? parseFloat(params.precoMax) : undefined

  // Mock properties - Replace with Hygraph query
  const allProperties = [
    {
      titulo: 'Apartamento T4 Premium em Luanda',
      preco: 85000000,
      slug: 'apartamento-t4-luanda',
      imagem: 'https://via.placeholder.com/400x300?text=Apartamento+1',
      tipo: 'Apartamento',
      cidade: 'Luanda',
      tipoVenda: 'venda' as const,
      quartos: 4,
      vagas: 2,
      area: 280,
    },
    {
      titulo: 'Vila Duplex em Bengo',
      preco: 125000000,
      slug: 'vila-duplex-bengo',
      imagem: 'https://via.placeholder.com/400x300?text=Vila+Bengo',
      tipo: 'Casa',
      cidade: 'Bengo',
      tipoVenda: 'venda' as const,
      quartos: 5,
      vagas: 3,
      area: 450,
    },
    {
      titulo: 'Lote Comercial em Luanda',
      preco: 95000000,
      slug: 'lote-comercial-luanda',
      imagem: 'https://via.placeholder.com/400x300?text=Comercial',
      tipo: 'Comercial',
      cidade: 'Luanda',
      tipoVenda: 'venda' as const,
      area: 350,
    },
    {
      titulo: 'Apartamento T2 Aluguel Luanda',
      preco: 4500000,
      slug: 'apartamento-t2-aluguel',
      imagem: 'https://via.placeholder.com/400x300?text=Apartamento+2',
      tipo: 'Apartamento',
      cidade: 'Luanda',
      tipoVenda: 'aluguel' as const,
      quartos: 2,
      vagas: 1,
      area: 120,
    },
  ]

  // Apply filters
  let filtered = allProperties
  if (cidade) {
    filtered = filtered.filter((p) => p.cidade === cidade)
  }
  if (precoMin !== undefined) {
    filtered = filtered.filter((p) => p.preco >= precoMin)
  }
  if (precoMax !== undefined) {
    filtered = filtered.filter((p) => p.preco <= precoMax)
  }

  // Pagination
  const itemsPerPage = 12
  const total = filtered.length
  const totalPages = Math.ceil(total / itemsPerPage)
  const start = (page - 1) * itemsPerPage
  const end = start + itemsPerPage
  const properties = filtered.slice(start, end)

  return (
    <main className="w-full">
      {/* Header */}
      <section className="section-bg-blue py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold text-gray-900">Imóveis</h1>
          <p className="mt-2 text-gray-600">Encontre o imóvel ideal em Angola</p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-8 md:py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-4">
            <div className="text-center text-white">
              <div className="text-3xl font-bold">{allProperties.length}</div>
              <div className="mt-1 text-sm text-blue-100">Imóveis Disponíveis</div>
            </div>
            <div className="text-center text-white">
              <div className="text-3xl font-bold">{allProperties.filter(p => p.tipoVenda === 'venda').length}</div>
              <div className="mt-1 text-sm text-blue-100">Para Venda</div>
            </div>
            <div className="text-center text-white">
              <div className="text-3xl font-bold">{allProperties.filter(p => p.tipoVenda === 'aluguel').length}</div>
              <div className="mt-1 text-sm text-blue-100">Para Aluguel</div>
            </div>
            <div className="text-center text-white">
              <div className="text-3xl font-bold">100%</div>
              <div className="mt-1 text-sm text-blue-100">Verificados</div>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-4">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <PropertyFilters />
            </div>

            {/* Main Content */}
            <div className="md:col-span-3">
              {properties.length > 0 ? (
                <>
                  {/* Results Count */}
                  <div className="mb-8">
                    <p className="text-sm text-gray-600">
                      Mostrando {start + 1}-{Math.min(end, total)} de {total} imóveis
                    </p>
                  </div>

                  {/* Grid */}
                  <div className="mb-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {properties.map((property) => (
                      <PropertyCard
                        key={property.slug}
                        titulo={property.titulo}
                        preco={property.preco}
                        slug={property.slug}
                        imagem={property.imagem}
                        tipo={property.tipo}
                        cidade={property.cidade}
                        quartos={property.quartos}
                        vagas={property.vagas}
                        area={property.area}
                      />
                    ))}
                  </div>

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <div className="flex justify-center">
                      <Pagination
                        pagina={page}
                        totalPaginas={totalPages}
                        onMudaPagina={(newPage) => {
                          const newParams = new URLSearchParams(
                            typeof window !== 'undefined' ? window.location.search : ''
                          )
                          newParams.set('page', newPage.toString())
                          window.location.href = `/imoveis?${newParams.toString()}`
                        }}
                      />
                    </div>
                  )}
                </>
              ) : (
                <div className="rounded-lg border border-gray-200 p-12 text-center">
                  <p className="text-gray-600">Nenhum imóvel encontrado com os filtros aplicados.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
