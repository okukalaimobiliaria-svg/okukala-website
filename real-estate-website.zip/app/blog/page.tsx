import { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { formatDate } from '@/lib/formatting'

export const metadata: Metadata = {
  title: 'Blog - OKUKALA Imobiliária',
  description: 'Artigos e dicas sobre o mercado imobiliário em Angola. Conheça tendências, guias de investimento e muito mais.',
}

export default function BlogPage() {
  // Mock blog posts - Replace with Hygraph query
  const posts = [
    {
      id: '1',
      titulo: 'Guia Completo: Comprar Imóvel em Angola',
      slug: 'guia-comprar-imovel-angola',
      descricao: 'Aprenda passo a passo como comprar um imóvel em Angola com segurança e tranquilidade.',
      imagemCapa: 'https://via.placeholder.com/400x250?text=Guia+Compra',
      data: new Date('2024-06-01').toISOString(),
    },
    {
      id: '2',
      titulo: 'Investimento Imobiliário em Luanda',
      slug: 'investimento-imovel-luanda',
      descricao: 'Descubra as melhores estratégias para investir em imóveis em Luanda e gerar retorno.',
      imagemCapa: 'https://via.placeholder.com/400x250?text=Investimento',
      data: new Date('2024-05-25').toISOString(),
    },
    {
      id: '3',
      titulo: 'Tendências do Mercado Imobiliário 2024',
      slug: 'tendencias-mercado-2024',
      descricao: 'Conheça as tendências mais importantes do mercado imobiliário angolano em 2024.',
      imagemCapa: 'https://via.placeholder.com/400x250?text=Tendencias',
      data: new Date('2024-05-15').toISOString(),
    },
    {
      id: '4',
      titulo: 'Como Avaliar um Imóvel Corretamente',
      slug: 'como-avaliar-imovel',
      descricao: 'Aprenda os critérios profissionais para avaliar um imóvel e fazer uma ótima negociação.',
      imagemCapa: 'https://via.placeholder.com/400x250?text=Avaliacao',
      data: new Date('2024-05-01').toISOString(),
    },
  ]

  return (
    <main className="w-full">
      {/* Header */}
      <section className="section-bg-blue py-16 md:py-24">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-gray-900">Blog OKUKALA</h1>
          <p className="mt-4 text-xl text-gray-600">Dicas, tendências e insights sobre o mercado imobiliário</p>
        </div>
      </section>

      {/* Search Section */}
      <section className="bg-white py-12 md:py-16 border-b border-gray-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">Pesquisar Artigos</h2>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Digite uma palavra-chave..."
                className="flex-1 rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
              />
              <button className="rounded-lg bg-okukala-blue px-6 py-2 font-semibold text-white transition-colors hover:bg-okukala-dark">
                Pesquisar
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="bg-gray-50 py-8 md:py-12 border-b border-gray-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="mb-4 text-sm font-semibold text-gray-600">CATEGORIAS</p>
          <div className="flex flex-wrap gap-3">
            {[
              'Compra e Venda',
              'Investimento',
              'Aluguel',
              'Mercado',
              'Dicas e Guias',
              'Tendências',
              'Financiamento',
              'Jurídico',
            ].map((category) => (
              <button
                key={category}
                className="rounded-full border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 transition-all hover:border-okukala-blue hover:section-bg-blue hover:text-okukala-blue"
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-2">
            {posts.map((post) => (
              <Link
                key={post.id}
                href={`/blog/${post.slug}`}
                className="group overflow-hidden rounded-lg border border-gray-200 transition-all hover:shadow-lg"
              >
                {/* Image */}
                <div className="relative h-48 w-full overflow-hidden bg-gray-100">
                  <Image
                    src={post.imagemCapa}
                    alt={post.titulo}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>

                {/* Content */}
                <div className="p-6">
                  <p className="text-sm text-gray-500">{formatDate(post.data)}</p>
                  <h3 className="mt-2 text-xl font-bold text-gray-900 group-hover:text-okukala-blue transition-colors">
                    {post.titulo}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-gray-600">{post.descricao}</p>
                  <div className="mt-4 inline-block text-sm font-semibold text-okukala-blue group-hover:underline">
                    Ler artigo →
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}
