import { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { formatDate } from '@/lib/formatting'

interface BlogPostPageProps {
  params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: BlogPostPageProps): Promise<Metadata> {
  const { slug } = await params

  return {
    title: `Artigo - OKUKALA Blog`,
    description: 'Leia nosso artigo completo sobre o mercado imobiliário em Angola.',
  }
}

export default async function BlogPostPage({ params }: BlogPostPageProps) {
  const { slug } = await params

  // Mock blog post - Replace with Hygraph query
  const post = {
    titulo: 'Guia Completo: Comprar Imóvel em Angola',
    data: new Date('2024-06-01').toISOString(),
    autor: 'OKUKALA Team',
    imagemCapa: 'https://via.placeholder.com/1200x600?text=Blog+Post',
    conteudo: `
      <p>Comprar um imóvel é uma das decisões mais importantes da vida. Para garantir que você faça a melhor escolha, preparamos este guia completo com todas as informações necessárias.</p>

      <h2>1. Defina Seu Orçamento</h2>
      <p>Antes de começar a procurar, é essencial saber quanto você pode investir. Considere todas as despesas associadas, como taxas de registro e possíveis reformas.</p>

      <h2>2. Escolha a Localização</h2>
      <p>A localização é um dos fatores mais importantes. Considere a proximidade de trabalho, escolas, comércios e o potencial de valorização da área.</p>

      <h2>3. Avalie o Imóvel</h2>
      <p>Contrate um avaliador profissional para verificar o estado do imóvel. Verifique também a documentação e certifique-se de que não há débitos pendentes.</p>

      <h2>4. Faça a Negociação</h2>
      <p>Não aceite o primeiro preço. Pesquise o mercado e negocie para obter as melhores condições possíveis.</p>

      <h2>5. Finalize a Transação</h2>
      <p>Com tudo acertado, procure um profissional legal para formalizar a transação e registrar o imóvel em seu nome.</p>

      <p>Seguindo estes passos, você estará preparado para comprar um imóvel com confiança e segurança.</p>
    `,
  }

  return (
    <main className="w-full">
      {/* Hero */}
      <section className="relative h-96 w-full overflow-hidden bg-gray-100">
        <Image
          src={post.imagemCapa}
          alt={post.titulo}
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
          <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
            <h1 className="text-4xl font-bold">{post.titulo}</h1>
            <div className="mt-4 flex justify-center gap-4 text-sm">
              <span>{formatDate(post.data)}</span>
              <span>•</span>
              <span>Por {post.autor}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-4">
            {/* Sidebar - Table of Contents */}
            <div className="md:col-span-1">
              <div className="rounded-lg border border-gray-200 p-6 sticky top-20 h-fit">
                <h3 className="mb-4 font-bold text-gray-900">Conteúdo</h3>
                <ul className="space-y-2 text-sm">
                  <li>
                    <a href="#" className="text-gray-600 hover:text-okukala-blue">
                      Defina Seu Orçamento
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-600 hover:text-okukala-blue">
                      Escolha a Localização
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-600 hover:text-okukala-blue">
                      Avalie o Imóvel
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-600 hover:text-okukala-blue">
                      Faça a Negociação
                    </a>
                  </li>
                  <li>
                    <a href="#" className="text-gray-600 hover:text-okukala-blue">
                      Finalize a Transação
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            {/* Main Content */}
            <div className="md:col-span-3">
              <div className="prose prose-neutral max-w-none" dangerouslySetInnerHTML={{ __html: post.conteudo }} />

              {/* Share Section */}
              <div className="mt-12 rounded-lg section-bg-blue border border-gray-200 p-6">
                <h3 className="mb-4 font-bold text-gray-900">Partilhe Este Artigo</h3>
                <div className="flex gap-3">
                  <button className="rounded-lg bg-okukala-blue px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-okukala-dark">
                    Facebook
                  </button>
                  <button className="rounded-lg bg-blue-400 px-4 py-2 text-sm font-semibold text-white transition-colors hover:section-bg-blue0">
                    Twitter
                  </button>
                  <button className="rounded-lg bg-okukala-dark px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-green-700">
                    WhatsApp
                  </button>
                </div>
              </div>

              {/* Back */}
              <div className="mt-8 border-t border-gray-200 pt-8">
                <Link href="/blog" className="text-okukala-blue hover:text-okukala-dark font-semibold">
                  ← Voltar para o Blog
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Articles */}
      <section className="border-t border-gray-200 bg-gray-50 py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-8 text-2xl font-bold text-gray-900">Artigos Relacionados</h2>
          
          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                titulo: 'Investimento Imobiliário em Luanda',
                slug: 'investimento-imovel-luanda',
                data: '25 Maio 2024',
                descricao: 'Descubra as melhores estratégias para investir em imóveis em Luanda.',
              },
              {
                titulo: 'Tendências do Mercado Imobiliário 2024',
                slug: 'tendencias-mercado-2024',
                data: '15 Maio 2024',
                descricao: 'Conheça as tendências mais importantes do mercado imobiliário angolano.',
              },
              {
                titulo: 'Como Avaliar um Imóvel Corretamente',
                slug: 'como-avaliar-imovel',
                data: '01 Maio 2024',
                descricao: 'Aprenda os critérios profissionais para avaliar um imóvel.',
              },
            ].map((article) => (
              <Link
                key={article.slug}
                href={`/blog/${article.slug}`}
                className="group rounded-lg border border-gray-200 bg-white p-6 transition-all hover:shadow-lg"
              >
                <div className="mb-4 h-32 w-full rounded-lg bg-gradient-to-br from-blue-100 to-blue-50 flex items-center justify-center">
                  <span className="text-okukala-blue font-bold">Imagem</span>
                </div>
                <p className="text-xs font-semibold text-okukala-blue">{article.data}</p>
                <h3 className="mt-2 font-bold text-gray-900 line-clamp-2 group-hover:text-okukala-blue">{article.titulo}</h3>
                <p className="mt-2 text-sm text-gray-600 line-clamp-2">{article.descricao}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="bg-okukala-blue py-16 md:py-24">
        <div className="mx-auto max-w-2xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white">Receba Nossos Artigos por Email</h2>
          <p className="mt-4 text-blue-100">Inscreva-se na nossa newsletter para receber as últimas dicas e tendências do mercado imobiliário.</p>
          
          <div className="mt-8 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-center">
            <input
              type="email"
              placeholder="Seu melhor email"
              className="flex-1 max-w-xs rounded-lg px-4 py-3 focus:outline-none"
            />
            <button className="rounded-lg bg-white px-8 py-3 font-semibold text-okukala-blue transition-colors hover:bg-gray-100">
              Inscrever
            </button>
          </div>
        </div>
      </section>
    </main>
  )
}
