'use client'

import { useState } from 'react'
import { Mail, Phone, MapPin } from 'lucide-react'
import { ContactForm } from '@/components/ContactForm'

type TabType = 'fale' | 'trabalhe' | 'investidor'

export default function ContatoPage() {
  const [activeTab, setActiveTab] = useState<TabType>('fale')

  const tabs = [
    { id: 'fale', label: 'Fale Connosco' },
    { id: 'trabalhe', label: 'Trabalhe Connosco' },
    { id: 'investidor', label: 'Portal do Investidor' },
  ] as const

  return (
    <main className="w-full">
      {/* Hero */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-white">Contacte-nos</h1>
          <p className="mt-4 text-blue-100">Estamos aqui para ajudar. Escolha a opção que melhor se adequa às suas necessidades.</p>
        </div>
      </section>

      {/* Tabs */}
      <section className="py-12 md:py-16">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          {/* Tab Buttons */}
          <div className="mb-8 flex flex-wrap gap-2 border-b border-gray-200 md:gap-4">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 font-semibold transition-colors ${
                  activeTab === tab.id
                    ? 'border-b-2 border-okukala-blue text-okukala-blue'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab 1: Fale Connosco */}
          {activeTab === 'fale' && (
            <div className="grid gap-8 md:grid-cols-2">
              {/* Info */}
              <div className="space-y-6">
                <div>
                  <h2 className="mb-2 text-2xl font-bold text-gray-900">Fale Connosco</h2>
                  <p className="text-gray-600">Tem dúvidas ou gostaria de enviar uma sugestão? Entre em contacto connosco directamente.</p>
                </div>

                <div className="space-y-4">
                  <div className="flex gap-3">
                    <Phone size={20} className="flex-shrink-0 text-okukala-blue mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900">Telefone</h3>
                      <a href="tel:+244912345678" className="text-okukala-blue hover:text-okukala-dark">
                        +244 912 345 678
                      </a>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <Mail size={20} className="flex-shrink-0 text-okukala-blue mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900">Email</h3>
                      <a href="mailto:contato@okukala.ao" className="text-okukala-blue hover:text-okukala-dark">
                        contato@okukala.ao
                      </a>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <MapPin size={20} className="flex-shrink-0 text-okukala-blue mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900">Localização</h3>
                      <p className="text-gray-600">Luanda, Angola</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form */}
              <div>
                <ContactForm />
              </div>
            </div>
          )}

          {/* Tab 2: Trabalhe Connosco */}
          {activeTab === 'trabalhe' && (
            <div className="space-y-8">
              <div>
                <h2 className="mb-4 text-2xl font-bold text-gray-900">Oportunidades de Carreira</h2>
                <p className="text-gray-600">
                  Na OKUKALA, valorizamos talento, inovação e compromisso. Junte-se a uma equipa dinâmica que está transformando o mercado imobiliário em Angola.
                </p>
              </div>

              {/* Jobs List */}
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-gray-900">Vagas Disponíveis</h3>

                <div className="space-y-3">
                  {[
                    { title: 'Consultor Imobiliário', location: 'Luanda' },
                    { title: 'Gestor de Propriedades', location: 'Luanda' },
                    { title: 'Especialista em Marketing Digital', location: 'Luanda' },
                  ].map((job, idx) => (
                    <button
                      key={idx}
                      className="w-full rounded-lg border border-gray-200 p-4 text-left transition-colors hover:section-bg-blue"
                    >
                      <h4 className="font-semibold text-gray-900">{job.title}</h4>
                      <p className="text-sm text-gray-600">{job.location}</p>
                    </button>
                  ))}
                </div>

                <button className="w-full rounded-lg border-2 border-okukala-blue py-2 font-semibold text-okukala-blue transition-colors hover:section-bg-blue">
                  Ver Mais Vagas
                </button>
              </div>

              {/* Application Form */}
              <div className="rounded-lg bg-gray-50 p-6">
                <h3 className="mb-4 text-lg font-semibold text-gray-900">Envie-nos o seu Currículo</h3>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Nome Completo</label>
                    <input
                      type="text"
                      className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                      placeholder="Seu nome"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Email</label>
                    <input
                      type="email"
                      className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                      placeholder="seu@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Telefone</label>
                    <input
                      type="tel"
                      className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                      placeholder="+244 912 345 678"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Cargo de Interesse</label>
                    <select className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none">
                      <option>Seleccione uma vaga</option>
                      <option>Consultor Imobiliário</option>
                      <option>Gestor de Propriedades</option>
                      <option>Especialista em Marketing Digital</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Mensagem</label>
                    <textarea
                      rows={4}
                      className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                      placeholder="Conte-nos um pouco sobre você..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full rounded-lg bg-okukala-blue py-2 font-semibold text-white transition-colors hover:bg-okukala-dark"
                  >
                    Enviar Candidatura
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Tab 3: Portal do Investidor */}
          {activeTab === 'investidor' && (
            <div className="space-y-8">
              <div>
                <h2 className="mb-4 text-2xl font-bold text-gray-900">Oportunidades de Investimento</h2>
                <p className="text-gray-600">
                  Explore oportunidades de investimento imobiliário de alta rentabilidade em Angola. O mercado imobiliário oferece retornos atractivos para investidores estratégicos.
                </p>
              </div>

              {/* Investment Options */}
              <div className="grid gap-6 md:grid-cols-2">
                {[
                  { title: 'Residential', description: 'Investimentos em habitação residencial de qualidade' },
                  { title: 'Comercial', description: 'Espaços comerciais prime location' },
                  { title: 'Industrial', description: 'Propriedades para fins industriais' },
                  { title: 'Desenvolvimento', description: 'Projectos de desenvolvimento imobiliário' },
                ].map((option, idx) => (
                  <div key={idx} className="rounded-lg border border-gray-200 p-6">
                    <h3 className="mb-2 font-semibold text-gray-900">{option.title}</h3>
                    <p className="text-sm text-gray-600">{option.description}</p>
                  </div>
                ))}
              </div>

              {/* Investor Form */}
              <div className="rounded-lg section-bg-blue p-8">
                <h3 className="mb-6 text-lg font-semibold text-gray-900">Manifestar Interesse</h3>
                <form className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Nome</label>
                      <input
                        type="text"
                        className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                        placeholder="Seu nome"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Email</label>
                      <input
                        type="email"
                        className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Telefone</label>
                      <input
                        type="tel"
                        className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                        placeholder="+244 912 345 678"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Tipo de Investimento</label>
                      <select className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none">
                        <option>Seleccione</option>
                        <option>Residential</option>
                        <option>Comercial</option>
                        <option>Industrial</option>
                        <option>Desenvolvimento</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Mensagem</label>
                    <textarea
                      rows={5}
                      className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                      placeholder="Descreva seu interesse e preferências de investimento..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full rounded-lg bg-okukala-blue py-3 font-semibold text-white transition-colors hover:bg-okukala-dark"
                  >
                    Solicitar Informações
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </section>
    </main>
  )
}
