import Link from 'next/link'
import { HeroSection } from '@/components/HeroSection'
import { PropertyCard } from '@/components/PropertyCard'
import { ArrowRight } from 'lucide-react'

export default function Page() {
  // Mock featured properties - Replace with actual Hygraph query
  const featuredProperties = [
    {
      titulo: 'Apartamento T4 Premium em Luanda',
      preco: 85000000,
      slug: 'apartamento-t4-luanda',
      imagem: 'https://via.placeholder.com/400x300?text=Apartamento+Luanda',
      tipo: 'Apartamento',
      cidade: 'Luanda',
      quartos: 4,
      vagas: 2,
      area: 280,
    },
    {
      titulo: 'Vila Duplex em Bengo',
      preco: 125000000,
      slug: 'vila-duplex-bengo',
      imagem: 'https://via.placeholder.com/400x300?text=Vila+Bengo',
      tipo: 'Casa',
      cidade: 'Bengo',
      quartos: 5,
      vagas: 3,
      area: 450,
    },
    {
      titulo: 'Lote Comercial em Luanda',
      preco: 95000000,
      slug: 'lote-comercial-luanda',
      imagem: 'https://via.placeholder.com/400x300?text=Comercial',
      tipo: 'Comercial',
      cidade: 'Luanda',
      area: 350,
    },
  ]

  return (
    <main className="w-full">
      {/* Hero Section */}
      <HeroSection />

      {/* Quick Search Section */}
      <section className="bg-white py-12 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="rounded-lg bg-gradient-to-r from-blue-50 to-blue-100 p-8 md:p-12">
            <h2 className="mb-6 text-2xl font-bold text-black">Pesquise por Imóvel</h2>
            <div className="grid gap-4 md:grid-cols-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Localização</label>
                <input
                  type="text"
                  placeholder="Cidade ou bairro"
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Imóvel</label>
                <select className="w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none">
                  <option>Todos</option>
                  <option>Apartamento</option>
                  <option>Casa</option>
                  <option>Comercial</option>
                  <option>Terreno</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Preço Máximo</label>
                <input
                  type="number"
                  placeholder="Valor máximo"
                  className="w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
                />
              </div>
              <div className="flex items-end">
                <Link
                  href="/imoveis"
                  className="w-full rounded-lg bg-okukala-blue px-6 py-2 font-semibold text-white transition-colors hover:bg-okukala-dark text-center"
                >
                  Pesquisar
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties Section */}
      <section className="bg-gray-50 py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-12 flex items-end justify-between">
            <div>
              <h2 className="text-3xl font-bold text-black">Imóveis em Destaque</h2>
              <p className="mt-2 text-gray-600">Conheça nossas propriedades mais procuradas</p>
            </div>
            <Link href="/imoveis" className="hidden items-center gap-2 text-okukala-blue hover:text-okukala-dark md:flex">
              Ver Todos
              <ArrowRight size={18} />
            </Link>
          </div>

          {/* Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {featuredProperties.map((property) => (
              <PropertyCard
                key={property.slug}
                titulo={property.titulo}
                preco={property.preco}
                slug={property.slug}
                imagem={property.imagem}
                tipo={property.tipo}
                cidade={property.cidade}
                quartos={property.quartos}
                vagas={property.vagas}
                area={property.area}
              />
            ))}
          </div>

          {/* CTA */}
          <div className="mt-10 text-center md:hidden">
            <Link
              href="/imoveis"
              className="inline-flex items-center gap-2 rounded-lg bg-okukala-blue px-6 py-3 font-semibold text-white transition-colors hover:bg-okukala-dark"
            >
              Ver Todos os Imóveis
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* Investment Opportunities Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-700 py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold text-white">Oportunidades de Investimento</h2>
            <p className="mt-2 text-blue-100">Imóveis com alto potencial de retorno em Angola</p>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                titulo: 'Terrenos Prime',
                descricao: 'Terrenos em localização estratégica para desenvolvimento imobiliário',
                valor: 'A partir de 50M Kz',
                rentabilidade: '+15% ao ano',
              },
              {
                titulo: 'Edifícios Comerciais',
                descricao: 'Propriedades comerciais com inquilinos e receita garantida',
                valor: 'A partir de 200M Kz',
                rentabilidade: '+12% ao ano',
              },
              {
                titulo: 'Projetos Residenciais',
                descricao: 'Participação em projetos residenciais de grande escala',
                valor: 'Mínimo de 500M Kz',
                rentabilidade: '+18% ao ano',
              },
            ].map((opp, idx) => (
              <div key={idx} className="rounded-lg bg-white p-6 shadow-lg">
                <h3 className="mb-2 font-bold text-gray-900 text-lg">{opp.titulo}</h3>
                <p className="mb-4 text-gray-600 text-sm">{opp.descricao}</p>
                <div className="space-y-2 border-t border-gray-200 pt-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Valor:</span>
                    <span className="font-semibold text-gray-900">{opp.valor}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Retorno:</span>
                    <span className="font-semibold text-okukala-blue">{opp.rentabilidade}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              href="/contato?tab=investidor"
              className="rounded-lg bg-white px-8 py-3 font-semibold text-okukala-blue transition-colors hover:bg-gray-100"
            >
              Conheça Nossas Oportunidades
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold text-gray-900">Por Que Escolher a OKUKALA?</h2>
            <p className="mt-2 text-gray-600">Sua parceira imobiliária premium em Angola</p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                titulo: 'Transparência Total',
                descricao: 'Todos os preços e informações são verificados para garantir autenticidade',
                icon: '🔍',
              },
              {
                titulo: 'Agentes Profissionais',
                descricao: 'Nossa equipe está pronta para ajudar em cada etapa do processo',
                icon: '👥',
              },
              {
                titulo: 'Tecnologia Avançada',
                descricao: 'Ferramentas modernas para encontrar o imóvel perfeito facilmente',
                icon: '⚡',
              },
            ].map((feature, idx) => (
              <div key={idx} className="rounded-lg border border-gray-200 p-8 text-center transition-all hover:shadow-lg">
                <div className="mb-4 text-4xl">{feature.icon}</div>
                <h3 className="mb-2 font-bold text-gray-900">{feature.titulo}</h3>
                <p className="text-gray-600">{feature.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Blog Articles Section */}
      <section className="bg-gray-50 py-16 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 flex items-end justify-between">
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Últimas Notícias e Artigos</h2>
              <p className="mt-2 text-gray-600">Acompanhe as tendências do mercado imobiliário</p>
            </div>
            <Link href="/blog" className="hidden items-center gap-2 text-okukala-blue hover:text-okukala-dark md:flex">
              Ver Todos
              <ArrowRight size={18} />
            </Link>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {[
              {
                titulo: 'Mercado Imobiliário em Angola: Oportunidades em 2024',
                descricao: 'Análise completa das tendências e oportunidades no setor imobiliário angolano para este ano.',
                data: '15 Junho 2024',
                autor: 'João Silva',
                imagem: 'https://via.placeholder.com/400x250?text=Blog+1',
              },
              {
                titulo: 'Como Investir em Imóveis com Sucesso',
                descricao: 'Guia prático com dicas essenciais para quem quer começar a investir em imóveis.',
                data: '10 Junho 2024',
                autor: 'Maria Santos',
                imagem: 'https://via.placeholder.com/400x250?text=Blog+2',
              },
              {
                titulo: 'Tendências de Design em Imóveis Residenciais',
                descricao: 'Conheça os principais estilos e tendências que estão transformando imóveis residenciais.',
                data: '05 Junho 2024',
                autor: 'Pedro Oliveira',
                imagem: 'https://via.placeholder.com/400x250?text=Blog+3',
              },
            ].map((article, idx) => (
              <Link
                key={idx}
                href="/blog"
                className="group rounded-lg border border-gray-200 overflow-hidden transition-all hover:shadow-lg"
              >
                <div className="relative h-48 overflow-hidden bg-gray-200">
                  <img
                    src={article.imagem}
                    alt={article.titulo}
                    className="h-full w-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <h3 className="mb-2 font-bold text-gray-900 line-clamp-2 group-hover:text-okukala-blue">{article.titulo}</h3>
                  <p className="mb-4 text-sm text-gray-600 line-clamp-2">{article.descricao}</p>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{article.data}</span>
                    <span>{article.autor}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-10 text-center md:hidden">
            <Link
              href="/blog"
              className="inline-flex items-center gap-2 rounded-lg bg-okukala-blue px-6 py-3 font-semibold text-white transition-colors hover:bg-okukala-dark"
            >
              Ver Todos os Artigos
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Final Section */}
      <section className="bg-okukala-blue py-16 md:py-24">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white">Pronto para Encontrar seu Imóvel em Angola?</h2>
          <p className="mt-4 text-blue-50">Explore nosso portfolio de propriedades premium e encontre a sua</p>
          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Link
              href="/imoveis?tipoVenda=venda"
              className="rounded-lg bg-white px-8 py-3 font-semibold text-okukala-blue transition-colors hover:bg-gray-100"
            >
              Ver Imóveis à Venda
            </Link>
            <Link
              href="/contato"
              className="rounded-lg border-2 border-white px-8 py-3 font-semibold text-white transition-colors hover:bg-white hover:text-okukala-blue"
            >
              Fale Conosco
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
