'use client'

import { useState } from 'react'
import { sendContactForm } from '@/lib/emailjs'

export function ContactForm() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    mensagem: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess(false)

    try {
      await sendContactForm(formData)
      setSuccess(true)
      setFormData({ nome: '', email: '', telefone: '', mensagem: '' })
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError('Erro ao enviar mensagem. Tente novamente.')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="nome" className="block text-sm font-medium text-gray-900">
          Nome
        </label>
        <input
          type="text"
          id="nome"
          name="nome"
          value={formData.nome}
          onChange={handleChange}
          required
          className="mt-1 w-full rounded-lg border border-gray-300 px-4 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-900">
            Email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className="mt-1 w-full rounded-lg border border-gray-300 px-4 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
          />
        </div>

        <div>
          <label htmlFor="telefone" className="block text-sm font-medium text-gray-900">
            Telefone
          </label>
          <input
            type="tel"
            id="telefone"
            name="telefone"
            value={formData.telefone}
            onChange={handleChange}
            required
            className="mt-1 w-full rounded-lg border border-gray-300 px-4 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
          />
        </div>
      </div>

      <div>
        <label htmlFor="mensagem" className="block text-sm font-medium text-gray-900">
          Mensagem
        </label>
        <textarea
          id="mensagem"
          name="mensagem"
          value={formData.mensagem}
          onChange={handleChange}
          required
          rows={5}
          className="mt-1 w-full rounded-lg border border-gray-300 px-4 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
        />
      </div>

      {error && <div className="rounded-lg bg-red-50 p-3 text-sm text-red-600">{error}</div>}
      {success && (
        <div className="rounded-lg bg-blue-50 p-3 text-sm text-okukala-blue">
          Mensagem enviada com sucesso! Obrigado por contatar a OKUKALA.
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-lg bg-okukala-blue px-6 py-3 font-semibold text-white transition-colors hover:bg-okukala-dark disabled:opacity-50"
      >
        {loading ? 'Enviando...' : 'Enviar Mensagem'}
      </button>
    </form>
  )
}
