'use client'

import { useState } from 'react'
import { Calendar, Clock, X } from 'lucide-react'

interface AppointmentFormProps {
  isOpen: boolean
  onClose: () => void
  propertyTitle: string
  slug: string
}

export function AppointmentForm({ isOpen, onClose, propertyTitle, slug }: AppointmentFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    data: '',
    hora: '',
    mensagem: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    try {
      // Aqui você integraria com o serviço de envio de emails
      console.log('Agendamento solicitado:', { ...formData, slug, propertyTitle })
      alert('Agendamento solicitado com sucesso! Entraremos em contacto em breve.')
      setFormData({ nome: '', email: '', telefone: '', data: '', hora: '', mensagem: '' })
      onClose()
    } catch (error) {
      console.error('Erro ao agendar visita:', error)
      alert('Erro ao agendar visita. Tente novamente.')
    } finally {
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="relative max-h-screen w-full max-w-md overflow-y-auto rounded-lg bg-white p-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1 hover:bg-gray-100"
          aria-label="Fechar"
        >
          <X size={20} />
        </button>

        {/* Header */}
        <div className="mb-6 pr-8">
          <h2 className="text-2xl font-bold text-gray-900">Agendar Visita</h2>
          <p className="mt-2 text-sm text-gray-600">{propertyTitle}</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Nome Completo *</label>
            <input
              type="text"
              name="nome"
              value={formData.nome}
              onChange={handleChange}
              required
              className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
              placeholder="Seu nome"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Email *</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
              placeholder="seu@email.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Telefone *</label>
            <input
              type="tel"
              name="telefone"
              value={formData.telefone}
              onChange={handleChange}
              required
              className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
              placeholder="+244 912 345 678"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700">Data Preferida *</label>
              <div className="relative">
                <Calendar size={18} className="absolute left-3 top-3 text-gray-400" />
                <input
                  type="date"
                  name="data"
                  value={formData.data}
                  onChange={handleChange}
                  required
                  className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 pl-10 focus:border-okukala-blue focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Hora Preferida *</label>
              <div className="relative">
                <Clock size={18} className="absolute left-3 top-3 text-gray-400" />
                <input
                  type="time"
                  name="hora"
                  value={formData.hora}
                  onChange={handleChange}
                  required
                  className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 pl-10 focus:border-okukala-blue focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Mensagem Adicional</label>
            <textarea
              name="mensagem"
              value={formData.mensagem}
              onChange={handleChange}
              rows={3}
              className="mt-1 w-full rounded-lg border border-gray-200 px-4 py-2 focus:border-okukala-blue focus:outline-none"
              placeholder="Deixe uma mensagem (opcional)..."
            />
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 rounded-lg border border-gray-200 py-2 font-semibold text-gray-700 transition-colors hover:bg-gray-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 rounded-lg bg-okukala-blue py-2 font-semibold text-white transition-colors hover:bg-okukala-dark disabled:opacity-50"
            >
              {isLoading ? 'Agendando...' : 'Agendar Visita'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
