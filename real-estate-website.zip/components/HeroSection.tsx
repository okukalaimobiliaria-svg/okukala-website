'use client'

import { useState } from 'react'
import { Search, ChevronRight } from 'lucide-react'
import Image from 'next/image'

export function HeroSection() {
  const [activeTab, setActiveTab] = useState('buy')
  const [searchQuery, setSearchQuery] = useState('')

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    console.log(`[v0] Search for: ${searchQuery} in ${activeTab} mode`)
  }

  return (
    <div className="relative w-full min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/hero-property.png"
          alt="Luxury modern house"
          fill
          className="object-cover"
          priority
        />
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/70 via-slate-900/50 to-slate-900/30" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-6xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            {/* Headline */}
            <div className="space-y-6">
              <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight text-pretty">
                We Help To Buy, Sell & Rent Your House
              </h1>
              <p className="text-lg text-slate-200 leading-relaxed max-w-md">
                Discover your dream property or find the perfect tenant for your home with our comprehensive real estate platform.
              </p>
            </div>

            {/* Action Tabs */}
            <div className="flex gap-3 flex-wrap">
              {['buy', 'sell', 'rent'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-2 rounded-full font-medium transition-all ${
                    activeTab === tab
                      ? 'bg-okukala-gold text-black shadow-lg shadow-okukala-gold/30'
                      : 'bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm'
                  }`}
                >
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              ))}
            </div>

            {/* Search Form */}
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Search by Address, City, Street, ZIP"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-6 py-4 rounded-full bg-white/95 text-slate-900 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-okukala-blue transition-all shadow-lg"
                />
              </div>
              <button
                type="submit"
                className="px-8 py-4 bg-okukala-blue hover:bg-okukala-dark text-white rounded-full font-semibold flex items-center justify-center gap-2 transition-all shadow-lg hover:shadow-lg hover:shadow-okukala-blue/30"
              >
                <Search size={20} />
                <span className="hidden sm:inline">Search</span>
              </button>
            </form>

            {/* Trust Indicators */}
            <div className="pt-6 border-t border-white/20">
              <p className="text-sm text-slate-300 mb-4">Trusted by leading real estate partners</p>
              <div className="flex flex-wrap gap-4 opacity-75">
                <div className="text-white font-medium text-sm">LYND</div>
                <div className="text-white font-medium text-sm">PINNACLE</div>
                <div className="text-white font-medium text-sm">BRIDGE</div>
                <div className="text-white font-medium text-sm">DGYRISE</div>
              </div>
            </div>
          </div>

          {/* Right Side - Stats Card */}
          <div className="hidden lg:flex justify-end">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 text-white max-w-sm">
              <div className="space-y-6">
                <div>
                  <div className="text-4xl font-bold text-okukala-gold">2,480+</div>
                  <p className="text-slate-300 text-sm mt-2">Properties Available</p>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2">
                  <div className="bg-okukala-blue h-2 rounded-full w-3/4" />
                </div>
                <div className="flex gap-4">
                  <div>
                    <div className="text-2xl font-bold">1.2k</div>
                    <p className="text-xs text-slate-400">Happy Buyers</p>
                  </div>
                  <div>
                    <div className="text-2xl font-bold">890</div>
                    <p className="text-xs text-slate-400">New Listings</p>
                  </div>
                </div>
                <button className="w-full bg-okukala-blue hover:bg-okukala-dark text-white py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2">
                  Explore More
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <div className="text-white/60 text-sm">Scroll to explore</div>
        <div className="text-white/40 text-2xl mt-2">↓</div>
      </div>
    </div>
  )
}
