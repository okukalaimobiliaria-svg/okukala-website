'use client'

import { MessageCircle } from 'lucide-react'

export function WhatsAppButton() {
  const whatsappNumber = '244912345678'
  const message = 'Olá! Gostaria de mais informações sobre os serviços da OKUKALA.'
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`

  return (
    <a
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-okukala-blue text-white shadow-lg transition-all hover:bg-okukala-dark hover:scale-110 md:bottom-8 md:right-8"
      aria-label="Contactar via WhatsApp"
      title="Contactar via WhatsApp"
    >
      <MessageCircle size={24} />
    </a>
  )
}
