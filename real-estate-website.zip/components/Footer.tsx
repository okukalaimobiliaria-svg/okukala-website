import Link from 'next/link'
import { Mail, MapPin, Phone } from 'lucide-react'

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-gray-200 bg-gray-50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-okukala-blue to-okukala-dark" />
              <span className="font-bold text-okukala-dark">OKUKALA</span>
            </div>
            <p className="text-sm text-gray-600">
              Imobiliária premium em Angola com os melhores imóveis e atendimento de excelência.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 font-semibold text-black">Navegação</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/imoveis" className="text-gray-600 hover:text-okukala-blue">
                  Imóveis
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-600 hover:text-okukala-blue">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/sobre" className="text-gray-600 hover:text-okukala-blue">
                  Sobre
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="mb-4 font-semibold text-black">Recursos</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/contato" className="text-gray-600 hover:text-okukala-blue">
                  Contato
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-600 hover:text-okukala-blue">
                  Política de Privacidade
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 font-semibold text-black">Contato</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex gap-2 text-gray-600">
                <Phone size={16} className="flex-shrink-0 pt-0.5" />
                <a href="tel:+244912345678" className="hover:text-gray-900">
                  +244 912 345 678
                </a>
              </li>
              <li className="flex gap-2 text-gray-600">
                <Mail size={16} className="flex-shrink-0 pt-0.5" />
                <a href="mailto:contato@okukala.ao" className="hover:text-gray-900">
                  contato@okukala.ao
                </a>
              </li>
              <li className="flex gap-2 text-gray-600">
                <MapPin size={16} className="flex-shrink-0 pt-0.5" />
                <span>Luanda, Angola</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-gray-200 pt-8 text-center text-sm text-gray-600">
          <p>&copy; {currentYear} <span className="font-bold text-okukala-dark">OKUKALA</span>. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
