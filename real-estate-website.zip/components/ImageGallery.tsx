'use client'

import { useState } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface ImageGalleryProps {
  imagens: Array<{ url: string }>
  titulo: string
}

export function ImageGallery({ imagens, titulo }: ImageGalleryProps) {
  const [indiceAtual, setIndiceAtual] = useState(0)

  if (!imagens || imagens.length === 0) {
    return (
      <div className="aspect-video w-full rounded-lg bg-gray-100" />
    )
  }

  const imagemAtual = imagens[indiceAtual]

  const avancar = () => {
    setIndiceAtual((prev) => (prev + 1) % imagens.length)
  }

  const voltarr = () => {
    setIndiceAtual((prev) => (prev - 1 + imagens.length) % imagens.length)
  }

  return (
    <div className="space-y-4">
      {/* Main Image */}
      <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-gray-100">
        <Image
          src={imagemAtual.url}
          alt={`${titulo} - Foto ${indiceAtual + 1}`}
          fill
          className="object-cover"
        />

        {/* Navigation Buttons */}
        {imagens.length > 1 && (
          <>
            <button
              onClick={voltarr}
              className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2 transition-colors hover:bg-black/70"
              aria-label="Foto anterior"
            >
              <ChevronLeft size={24} className="text-white" />
            </button>
            <button
              onClick={avancar}
              className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2 transition-colors hover:bg-black/70"
              aria-label="Próxima foto"
            >
              <ChevronRight size={24} className="text-white" />
            </button>

            {/* Image Counter */}
            <div className="absolute bottom-4 right-4 rounded-full bg-black/50 px-3 py-1 text-sm text-white">
              {indiceAtual + 1} / {imagens.length}
            </div>
          </>
        )}
      </div>

      {/* Thumbnails */}
      {imagens.length > 1 && (
        <div className="flex gap-2 overflow-x-auto">
          {imagens.map((img, idx) => (
            <button
              key={idx}
              onClick={() => setIndiceAtual(idx)}
              className={`relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-lg border-2 transition-colors ${
                idx === indiceAtual ? 'border-blue-500' : 'border-transparent'
              }`}
            >
              <Image
                src={img.url}
                alt={`Thumbnail ${idx + 1}`}
                fill
                className="object-cover"
              />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
