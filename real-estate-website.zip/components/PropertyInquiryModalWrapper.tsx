'use client'

import { useState } from 'react'
import { PropertyInquiryModal } from '@/components/PropertyInquiryModal'

interface PropertyInquiryModalWrapperProps {
  slug: string
  titulo: string
}

export function PropertyInquiryModalWrapper({ slug, titulo }: PropertyInquiryModalWrapperProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="w-full rounded-lg bg-okukala-blue px-6 py-3 font-semibold text-white transition-colors hover:bg-okukala-dark"
      >
        Solicitar Informações
      </button>
      <PropertyInquiryModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        slug={slug}
        titulo={titulo}
      />
    </>
  )
}
