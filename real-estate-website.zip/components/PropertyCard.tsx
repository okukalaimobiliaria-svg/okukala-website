import Link from 'next/link'
import Image from 'next/image'
import { Bed, Bath, Maximize2 } from 'lucide-react'
import { formatPrice } from '@/lib/formatting'

interface PropertyCardProps {
  titulo: string
  preco: number
  slug: string
  imagem?: string
  tipo: string
  cidade: string
  quartos?: number
  vagas?: number
  area?: number
}

export function PropertyCard({
  titulo,
  preco,
  slug,
  imagem,
  tipo,
  cidade,
  quartos,
  vagas,
  area,
}: PropertyCardProps) {
  const imagemUrl = imagem || '/api/placeholder?w=400&h=300'

  return (
    <Link href={`/imoveis/${slug}`}>
      <div className="card-property">
        {/* Image Container */}
        <div className="relative h-64 w-full overflow-hidden bg-gray-100">
          <Image
            src={imagemUrl}
            alt={titulo}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute right-4 top-4 badge-blue">
            {tipo}
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="mb-2 line-clamp-2 font-semibold text-black">{titulo}</h3>

          {/* Price and Location */}
          <div className="mb-3 flex items-start justify-between">
            <div>
              <p className="text-2xl font-bold text-okukala-gold">{formatPrice(preco)}</p>
              <p className="text-sm text-gray-500">{cidade}</p>
            </div>
          </div>

          {/* Features */}
          <div className="flex flex-wrap gap-3 border-t border-gray-100 pt-3 text-xs text-gray-600">
            {quartos !== undefined && (
              <div className="flex items-center gap-1">
                <Bed size={14} />
                <span>{quartos}q</span>
              </div>
            )}
            {vagas !== undefined && (
              <div className="flex items-center gap-1">
                <Bath size={14} />
                <span>{vagas} vagas</span>
              </div>
            )}
            {area !== undefined && (
              <div className="flex items-center gap-1">
                <Maximize2 size={14} />
                <span>{area} m²</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </Link>
  )
}
