'use client'

import { ChevronLeft, ChevronRight } from 'lucide-react'

interface PaginationProps {
  pagina: number
  totalPaginas: number
  onMudaPagina: (pagina: number) => void
}

export function Pagination({ pagina, totalPaginas, onMudaPagina }: PaginationProps) {
  const paginas = []

  // Mostrar no máximo 5 páginas
  let inicio = Math.max(1, pagina - 2)
  let fim = Math.min(totalPaginas, pagina + 2)

  if (fim - inicio < 4) {
    if (inicio === 1) fim = Math.min(5, totalPaginas)
    else inicio = Math.max(1, fim - 4)
  }

  for (let i = inicio; i <= fim; i++) {
    paginas.push(i)
  }

  return (
    <div className="flex items-center justify-center gap-2">
      {/* Previous Button */}
      <button
        onClick={() => onMudaPagina(pagina - 1)}
        disabled={pagina === 1}
        className="rounded-lg border border-gray-300 p-2 transition-colors hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <ChevronLeft size={20} />
      </button>

      {/* Page Numbers */}
      <div className="flex gap-1">
        {inicio > 1 && (
          <>
            <button
              onClick={() => onMudaPagina(1)}
              className="rounded-lg border border-gray-300 px-3 py-2 text-sm transition-colors hover:bg-gray-100"
            >
              1
            </button>
            {inicio > 2 && <span className="px-2 py-2">...</span>}
          </>
        )}

        {paginas.map((p) => (
          <button
            key={p}
            onClick={() => onMudaPagina(p)}
            className={`rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
              p === pagina
                ? 'border-blue-500 section-bg-blue text-okukala-blue'
                : 'border-gray-300 hover:bg-gray-100'
            }`}
          >
            {p}
          </button>
        ))}

        {fim < totalPaginas && (
          <>
            {fim < totalPaginas - 1 && <span className="px-2 py-2">...</span>}
            <button
              onClick={() => onMudaPagina(totalPaginas)}
              className="rounded-lg border border-gray-300 px-3 py-2 text-sm transition-colors hover:bg-gray-100"
            >
              {totalPaginas}
            </button>
          </>
        )}
      </div>

      {/* Next Button */}
      <button
        onClick={() => onMudaPagina(pagina + 1)}
        disabled={pagina === totalPaginas}
        className="rounded-lg border border-gray-300 p-2 transition-colors hover:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <ChevronRight size={20} />
      </button>
    </div>
  )
}
