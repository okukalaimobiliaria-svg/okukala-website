'use client'

import { useState } from 'react'
import { PropertyInquiryModalWrapper } from '@/components/PropertyInquiryModalWrapper'
import { AppointmentForm } from '@/components/AppointmentForm'

interface PropertyDetailClientProps {
  slug: string
  titulo: string
}

export function PropertyDetailClient({ slug, titulo }: PropertyDetailClientProps) {
  const [isAppointmentOpen, setIsAppointmentOpen] = useState(false)

  return (
    <>
      <div className="flex flex-col gap-3 sm:flex-row">
        <button
          onClick={() => setIsAppointmentOpen(true)}
          className="flex-1 rounded-lg border-2 border-okukala-blue px-6 py-3 font-semibold text-okukala-blue transition-colors hover:section-bg-blue"
        >
          Agendar Visita
        </button>
        <PropertyInquiryModalWrapper slug={slug} titulo={titulo} />
      </div>
      <AppointmentForm
        isOpen={isAppointmentOpen}
        onClose={() => setIsAppointmentOpen(false)}
        slug={slug}
        propertyTitle={titulo}
      />
    </>
  )
}
