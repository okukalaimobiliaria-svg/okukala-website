'use client'

import { useRouter, useSearchParams } from 'next/navigation'

export function PropertyFilters() {
  const router = useRouter()
  const searchParams = useSearchParams()

  const handleFilterChange = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams)
    if (value) {
      params.set(key, value)
    } else {
      params.delete(key)
    }
    params.set('page', '1')
    router.push(`/imoveis?${params.toString()}`)
  }

  const tipoVenda = searchParams.get('tipoVenda') || ''
  const cidade = searchParams.get('cidade') || ''
  const precoMin = searchParams.get('precoMin') || ''
  const precoMax = searchParams.get('precoMax') || ''

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-6">
      <h3 className="mb-4 font-semibold text-gray-900">Filtros</h3>

      <div className="space-y-4">
        {/* Tipo de Venda */}
        <div>
          <label htmlFor="tipoVenda" className="block text-sm font-medium text-gray-900">
            Tipo
          </label>
          <select
            id="tipoVenda"
            value={tipoVenda}
            onChange={(e) => handleFilterChange('tipoVenda', e.target.value)}
            className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
          >
            <option value="">Todos</option>
            <option value="venda">Venda</option>
            <option value="aluguel">Aluguel</option>
          </select>
        </div>

        {/* Cidade */}
        <div>
          <label htmlFor="cidade" className="block text-sm font-medium text-gray-900">
            Cidade
          </label>
          <select
            id="cidade"
            value={cidade}
            onChange={(e) => handleFilterChange('cidade', e.target.value)}
            className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
          >
            <option value="">Todas</option>
            <option value="Luanda">Luanda</option>
            <option value="Bengo">Bengo</option>
            <option value="Cabinda">Cabinda</option>
            <option value="Cuando Cubango">Cuando Cubango</option>
            <option value="Cuanza Norte">Cuanza Norte</option>
            <option value="Cuanza Sul">Cuanza Sul</option>
            <option value="Cunene">Cunene</option>
            <option value="Huambo">Huambo</option>
            <option value="Huila">Huila</option>
            <option value="Kwanza Norte">Kwanza Norte</option>
            <option value="Kwanza Sul">Kwanza Sul</option>
            <option value="Kwanza Su">Kwanza Su</option>
            <option value="Lunda Norte">Lunda Norte</option>
            <option value="Lunda Sul">Lunda Sul</option>
            <option value="Malanje">Malanje</option>
            <option value="Moxico">Moxico</option>
            <option value="Namibe">Namibe</option>
            <option value="Uige">Uige</option>
            <option value="Zaire">Zaire</option>
          </select>
        </div>

        {/* Preço Mínimo */}
        <div>
          <label htmlFor="precoMin" className="block text-sm font-medium text-gray-900">
            Preço Mínimo (AOA)
          </label>
          <input
            type="number"
            id="precoMin"
            value={precoMin}
            onChange={(e) => handleFilterChange('precoMin', e.target.value)}
            placeholder="0"
            className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
          />
        </div>

        {/* Preço Máximo */}
        <div>
          <label htmlFor="precoMax" className="block text-sm font-medium text-gray-900">
            Preço Máximo (AOA)
          </label>
          <input
            type="number"
            id="precoMax"
            value={precoMax}
            onChange={(e) => handleFilterChange('precoMax', e.target.value)}
            placeholder="Sem limite"
            className="mt-2 w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 focus:border-okukala-blue focus:outline-none"
          />
        </div>

        {/* Clear Filters */}
        {(tipoVenda || cidade || precoMin || precoMax) && (
          <button
            onClick={() => router.push('/imoveis')}
            className="w-full rounded-lg border border-gray-300 py-2 text-sm font-semibold text-gray-900 transition-colors hover:bg-gray-50"
          >
            Limpar Filtros
          </button>
        )}
      </div>
    </div>
  )
}
