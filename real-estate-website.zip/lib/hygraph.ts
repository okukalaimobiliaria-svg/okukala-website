import { GraphQLClient } from 'graphql-request'

const endpoint = process.env.NEXT_PUBLIC_HYGRAPH_URL

if (!endpoint) {
  console.warn('[Hygraph] NEXT_PUBLIC_HYGRAPH_URL not configured. Using placeholder.')
}

export const hygraphClient = new GraphQLClient(endpoint || 'https://api-us-east-1-shared-usea-prod.hygraph.com/graphql/...')

// TypeScript types
export interface Imovel {
  id: string
  titulo: string
  slug: string
  descricao: string
  preco: number
  tipoVenda: 'venda' | 'aluguel'
  cidade: string
  bairro?: string
  quartos?: number
  vagas?: number
  area?: number
  imagens: Array<{ url: string }>
  destaqueHome: boolean
  status: 'disponivel' | 'vendido' | 'alugado'
  createdAt: string
}

export interface BlogPost {
  id: string
  titulo: string
  slug: string
  data: string
  conteudo: string
  imagemCapa: { url: string }
  categoria?: string
}
