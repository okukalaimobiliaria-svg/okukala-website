export const GET_HOME_IMOVEIS = `
  query GetHomeImoveis {
    imovels(where: { destaqueHome: true, status: disponivel }, first: 3) {
      id
      titulo
      slug
      preco
      cidade
      quartos
      vagas
      area
      imagens {
        url
      }
    }
  }
`

export const GET_ALL_IMOVEIS = `
  query GetAllImoveis($skip: Int!, $first: Int!, $cidade: String, $tipoVenda: String, $precoMin: Float, $precoMax: Float) {
    imovels(
      skip: $skip
      first: $first
      where: {
        cidade: $cidade
        tipoVenda: $tipoVenda
        preco_gte: $precoMin
        preco_lte: $precoMax
        status: disponivel
      }
      orderBy: createdAt_DESC
    ) {
      id
      titulo
      slug
      preco
      cidade
      quartos
      vagas
      area
      imagens {
        url
      }
      tipoVenda
    }
    imovelsConnection(
      where: {
        cidade: $cidade
        tipoVenda: $tipoVenda
        preco_gte: $precoMin
        preco_lte: $precoMax
        status: disponivel
      }
    ) {
      aggregate {
        count
      }
    }
  }
`

export const GET_IMOVEL_BY_SLUG = `
  query GetImovelBySlug($slug: String!) {
    imovels(where: { slug: $slug }, first: 1) {
      id
      titulo
      slug
      descricao
      preco
      tipoVenda
      cidade
      bairro
      quartos
      vagas
      area
      imagens {
        url
      }
      status
      createdAt
    }
  }
`

export const GET_BLOG_POSTS = `
  query GetBlogPosts($skip: Int!, $first: Int!) {
    blogPosts(
      skip: $skip
      first: $first
      orderBy: data_DESC
    ) {
      id
      titulo
      slug
      data
      categoria
      imagemCapa {
        url
      }
    }
    blogPostsConnection {
      aggregate {
        count
      }
    }
  }
`

export const GET_POST_BY_SLUG = `
  query GetPostBySlug($slug: String!) {
    blogPosts(where: { slug: $slug }, first: 1) {
      id
      titulo
      slug
      data
      conteudo
      imagemCapa {
        url
      }
      categoria
    }
  }
`

export const GET_IMOVEL_SLUGS = `
  query GetImovelSlugs {
    imovels(first: 1000, where: { status: disponivel }) {
      slug
    }
  }
`

export const GET_POST_SLUGS = `
  query GetPostSlugs {
    blogPosts(first: 1000) {
      slug
    }
  }
`
